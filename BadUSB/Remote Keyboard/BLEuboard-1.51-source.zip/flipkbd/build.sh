#!/bin/bash
# Builds and signs BLEuboard.apk.
# Signing key is kept outside the source tree:
#   KEYSTORE       path to the keystore (default: ../keystore.jks)
#   KEYSTORE_PASS  keystore/key password (prompted if not set)
#   KEY_ALIAS      key alias (default: flipkbd)
# If the keystore does not exist, a new one is generated at that path.
set -e
cd "$(dirname "$0")"
SDK=/usr/lib/android-sdk/platforms/android-23/android.jar
KEYSTORE="${KEYSTORE:-../keystore.jks}"
KEY_ALIAS="${KEY_ALIAS:-flipkbd}"
if [ -z "$KEYSTORE_PASS" ]; then
    read -r -s -p "Keystore password: " KEYSTORE_PASS
    echo
fi
export KEYSTORE_PASS

rm -rf build && mkdir -p build/gen build/classes
aapt package -f -m -J build/gen -M AndroidManifest.xml -S res -I $SDK -F build/res.apk
javac --release 8 -nowarn -encoding UTF-8 -classpath $SDK -d build/classes $(find src build/gen -name '*.java')
dalvik-exchange --dex --output=build/classes.dex build/classes
cp build/res.apk build/unsigned.apk
(cd build && zip -q unsigned.apk classes.dex)
zipalign -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f "$KEYSTORE" ]; then
    echo "Keystore not found, generating $KEYSTORE"
    keytool -genkeypair -keystore "$KEYSTORE" -storepass:env KEYSTORE_PASS -keypass:env KEYSTORE_PASS \
        -alias "$KEY_ALIAS" -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=BLEuboard" >/dev/null 2>&1
fi
apksigner sign --ks "$KEYSTORE" --ks-key-alias "$KEY_ALIAS" --ks-pass env:KEYSTORE_PASS --key-pass env:KEYSTORE_PASS \
    --out BLEuboard.apk build/aligned.apk
rm -f BLEuboard.apk.idsig
apksigner verify -v BLEuboard.apk | head -5
