package nl.zarco.flipkbd;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.widget.FrameLayout;
import android.view.inputmethod.InputMethodManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements FlipperLink.Listener {

    private static final String SCRIPT_DIR = "/ext/badusb";
    private static final String[] DEFAULT_APP_NAMES = {
            "Bad USB", "bad_usb", "/ext/apps/USB/bad_usb.fap", "/ext/apps/Tools/bad_usb.fap"};

    private static final String[][] QUICK_KEYS = {
            {"Esc", "ESC"}, {"Tab", "TAB"}, {"Space", "SPACE"}, {"Del", "DELETE"},
            {"Home", "HOME"}, {"End", "END"}, {"Win", "GUI"}, {"Alt+Tab", "ALT TAB"},
            {"Ctrl+A", "CTRL a"}, {"Ctrl+C", "CTRL c"}, {"Ctrl+V", "CTRL v"}, {"Ctrl+Z", "CTRL z"},
            {"Ctrl+S", "CTRL s"}, {"Win+R", "GUI r"}, {"Win+L", "GUI l"}, {"Ctrl+Alt+Del", "CTRL-ALT DELETE"},
    };

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private FlipperLink link;
    private SharedPreferences prefs;

    private TextView status;
    private LinearLayout controls;
    private Spinner deviceSpinner;
    private Button connectBtn;
    private EditText input;
    private CheckBox enterAfter;
    private CheckBox rawMode;
    private EditText repeatField;
    private EditText appNameField;
    private EditText delayField;
    private EditText charDelayField;
    private EditText lineDelayField;
    private CheckBox deadKeys;
    private TextView logView;

    private final List<BluetoothDevice> devices = new ArrayList<>();
    private int fileToggle = 0;
    private String workingAppName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        // One-time migration: old default char delay (15 ms) becomes the new default (50 ms)
        if (!prefs.getBoolean("charDelayMigrated50", false)) {
            SharedPreferences.Editor e = prefs.edit().putBoolean("charDelayMigrated50", true);
            if (prefs.getInt("charDelay", 15) == 15) e.putInt("charDelay", 50);
            e.apply();
        }
        link = new FlipperLink(this, this);
        buildUi();
        registerReceiver(btStateReceiver, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));
        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"}, 1);
        } else {
            loadDevices();
        }
    }

    /** Drops the link and hides the controls when Bluetooth is switched off on the phone. */
    private final BroadcastReceiver btStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
            if (state == BluetoothAdapter.STATE_TURNING_OFF || state == BluetoothAdapter.STATE_OFF) {
                final boolean was = link.isConnected();
                worker.execute(new Runnable() { public void run() {
                    link.disconnect();
                    if (was) onLog("Bluetooth turned off");
                    refreshConnectionUi();
                }});
            } else if (state == BluetoothAdapter.STATE_ON) {
                loadDevices();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        refreshConnectionUi();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        loadDevices();
    }

    @Override
    protected void onDestroy() {
        saveSettings();
        try {
            unregisterReceiver(btStateReceiver);
        } catch (Exception ignored) {
        }
        worker.execute(new Runnable() { public void run() { link.disconnect(); } });
        worker.shutdown();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- UI (Flipper Zero style)

    private static final int ORANGE = 0xFFFF8200;
    private static final int ORANGE_DARK = 0xFFC86400;
    private static final int BG = 0xFF0E0E0E;
    private static final int PANEL = 0xFF1B1B1B;
    private static final int PANEL_EDGE = 0xFF333333;
    private static final int TEXT = 0xFFEDEDED;
    private static final int TEXT_DIM = 0xFF8A8A8A;
    private static final int LCD_INK = 0xFF000000;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private GradientDrawable box(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(2), stroke);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable oval(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(2), stroke);
        return g;
    }

    private StateListDrawable states(Drawable normal, Drawable pressed) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, normal);
        return s;
    }

    private ColorStateList pressColors(int normal, int pressed) {
        return new ColorStateList(new int[][]{{android.R.attr.state_pressed}, {}}, new int[]{pressed, normal});
    }

    private Button fbtn(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setTextSize(13);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setStateListAnimator(null);
        if (primary) {
            b.setBackground(states(box(ORANGE, 0, 6), box(ORANGE_DARK, 0, 6)));
            b.setTextColor(LCD_INK);
        } else {
            b.setBackground(states(box(PANEL, PANEL_EDGE, 6), box(ORANGE, ORANGE, 6)));
            b.setTextColor(pressColors(ORANGE, LCD_INK));
        }
        return b;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTypeface(Typeface.MONOSPACE);
        e.setTextColor(TEXT);
        e.setHintTextColor(TEXT_DIM);
        e.setTextSize(14);
        e.setBackground(box(BG, PANEL_EDGE, 6));
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean has) {
                v.setBackground(box(BG, has ? ORANGE : PANEL_EDGE, 6));
            }
        });
        return e;
    }

    private TextView text(String s, int color, int sizeSp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(sizeSp);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    private TextView label(String s) {
        TextView t = text("> " + s.toUpperCase(Locale.ROOT), ORANGE, 13);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setPadding(dp(2), dp(16), 0, dp(6));
        return t;
    }

    private CheckBox check(String s, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(TEXT);
        c.setTextSize(13);
        c.setTypeface(Typeface.MONOSPACE);
        c.setButtonTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{ORANGE, TEXT_DIM}));
        c.setChecked(on);
        return c;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(box(PANEL, PANEL_EDGE, 10));
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        return c;
    }

    private View.OnClickListener keyClick(final String combo) {
        return new View.OnClickListener() { public void onClick(View v) { sendKey(combo); } };
    }

    /** Round Flipper-style directional pad: arrows around a centre OK (Enter). */
    private FrameLayout dpad() {
        int size = dp(176);
        FrameLayout pad = new FrameLayout(this);
        pad.setBackground(oval(PANEL, PANEL_EDGE));
        String[][] arrows = {{"▲", "UP"}, {"▼", "DOWN"}, {"◀", "LEFT"}, {"▶", "RIGHT"}};
        int[] gravity = {Gravity.TOP | Gravity.CENTER_HORIZONTAL, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL,
                Gravity.LEFT | Gravity.CENTER_VERTICAL, Gravity.RIGHT | Gravity.CENTER_VERTICAL};
        for (int i = 0; i < 4; i++) {
            Button b = new Button(this);
            b.setText(arrows[i][0]);
            b.setTextSize(18);
            b.setStateListAnimator(null);
            b.setPadding(0, 0, 0, 0);
            b.setBackground(states(oval(0x00000000, 0), oval(ORANGE, 0)));
            b.setTextColor(pressColors(ORANGE, LCD_INK));
            b.setOnClickListener(keyClick(arrows[i][1]));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(56), dp(56), gravity[i]);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            pad.addView(b, lp);
        }
        Button ok = new Button(this);
        ok.setText("OK");
        ok.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        ok.setTextSize(15);
        ok.setStateListAnimator(null);
        ok.setPadding(0, 0, 0, 0);
        ok.setBackground(states(oval(BG, ORANGE), oval(ORANGE, ORANGE)));
        ok.setTextColor(pressColors(ORANGE, LCD_INK));
        ok.setOnClickListener(keyClick("ENTER"));
        pad.addView(ok, new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER));
        pad.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        return pad;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(14), dp(14), dp(14), dp(20));

        // LCD screen: orange backlight, black pixels
        LinearLayout lcd = new LinearLayout(this);
        lcd.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable lcdBg = box(ORANGE, 0xFF2A2A2A, 6);
        lcdBg.setStroke(dp(6), 0xFF2A2A2A);
        lcd.setBackground(lcdBg);
        lcd.setPadding(dp(16), dp(12), dp(16), dp(14));
        TextView title = text("BLEuboard", LCD_INK, 12);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setLetterSpacing(0.15f);
        lcd.addView(title);
        View rule = new View(this);
        rule.setBackgroundColor(LCD_INK);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        rlp.setMargins(0, dp(4), 0, dp(8));
        lcd.addView(rule, rlp);
        status = text("Not connected", LCD_INK, 17);
        status.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        lcd.addView(status);
        root.addView(lcd);

        LinearLayout devRow = row();
        devRow.setPadding(0, dp(10), 0, 0);
        deviceSpinner = new Spinner(this);
        deviceSpinner.setBackground(box(PANEL, PANEL_EDGE, 6));
        deviceSpinner.setPopupBackgroundDrawable(new ColorDrawable(PANEL));
        deviceSpinner.setMinimumHeight(dp(44));
        devRow.addView(deviceSpinner, weight(1));
        Button refresh = fbtn("↻", false);
        refresh.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { loadDevices(); } });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.setMargins(dp(3), dp(3), dp(3), dp(3));
        devRow.addView(refresh, rp);
        connectBtn = fbtn("Connect", true);
        connectBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleConnect(); } });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dp(3), dp(3), dp(3), dp(3));
        connectBtn.setPadding(dp(14), 0, dp(14), 0);
        devRow.addView(connectBtn, cp);
        root.addView(devRow);

        // Text
        // Everything below is only shown while a verified connection exists.
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setVisibility(View.GONE);
        controls.addView(label("Text"));
        input = field("Type text for the computer");
        input.setMinLines(4);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        controls.addView(input);

        LinearLayout optRow = row();
        enterAfter = check("Enter after text", prefs.getBoolean("enterAfter", false));
        optRow.addView(enterAfter, weight(1));
        rawMode = check("Raw DuckyScript", prefs.getBoolean("raw", false));
        optRow.addView(rawMode, weight(1));
        controls.addView(optRow);

        LinearLayout sendRow = row();
        Button send = fbtn("Send ▶", true);
        send.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sendText(); } });
        sendRow.addView(send, weight(2));
        Button load = fbtn("Load .txt", false);
        load.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickTextFile(); } });
        sendRow.addView(load, weight(1.5f));
        Button clear = fbtn("Clear", false);
        clear.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { input.setText(""); } });
        sendRow.addView(clear, weight(1));
        controls.addView(sendRow);

        // Keys: D-pad + back, then grid
        LinearLayout keysHeader = row();
        keysHeader.addView(label("Keys"), weight(1));
        keysHeader.addView(text("Repeat × ", TEXT_DIM, 13));
        repeatField = field("1");
        repeatField.setInputType(InputType.TYPE_CLASS_NUMBER);
        repeatField.setText("1");
        repeatField.setSelectAllOnFocus(true);
        repeatField.setGravity(Gravity.CENTER);
        keysHeader.addView(repeatField, new LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT));
        controls.addView(keysHeader);

        LinearLayout keysCard = card();
        LinearLayout padRow = row();
        padRow.setGravity(Gravity.CENTER);
        padRow.addView(dpad());
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setGravity(Gravity.CENTER_HORIZONTAL);
        side.setPadding(dp(22), dp(60), 0, 0);
        Button back = new Button(this);
        back.setText("⌫");
        back.setTextSize(20);
        back.setStateListAnimator(null);
        back.setPadding(0, 0, 0, 0);
        back.setBackground(states(oval(PANEL, PANEL_EDGE), oval(ORANGE, ORANGE)));
        back.setTextColor(pressColors(ORANGE, LCD_INK));
        back.setOnClickListener(keyClick("BACKSPACE"));
        side.addView(back, new LinearLayout.LayoutParams(dp(60), dp(60)));
        side.addView(text("BKSP", TEXT_DIM, 11));
        padRow.addView(side);
        keysCard.addView(padRow);

        View gap = new View(this);
        keysCard.addView(gap, new LinearLayout.LayoutParams(1, dp(10)));
        LinearLayout keyRow = null;
        for (int i = 0; i < QUICK_KEYS.length; i++) {
            if (i % 4 == 0) {
                keyRow = row();
                keysCard.addView(keyRow);
            }
            Button b = fbtn(QUICK_KEYS[i][0], false);
            b.setTextSize(QUICK_KEYS[i][0].length() > 8 ? 10 : 12);
            b.setOnClickListener(keyClick(QUICK_KEYS[i][1]));
            keyRow.addView(b, weight(1));
        }
        controls.addView(keysCard);

        // Advanced
        controls.addView(label("Advanced"));
        LinearLayout adv = card();
        LinearLayout advRow = row();
        advRow.addView(text("Bad USB app ", TEXT, 13));
        appNameField = field("auto");
        appNameField.setSingleLine(true);
        appNameField.setText(prefs.getString("appName", ""));
        advRow.addView(appNameField, weight(1));
        adv.addView(advRow);

        LinearLayout delayRow = row();
        delayRow.setPadding(0, dp(6), 0, 0);
        delayField = numberField(prefs.getInt("delay", 500));
        charDelayField = numberField(prefs.getInt("charDelay", 50));
        lineDelayField = numberField(prefs.getInt("lineDelay", 30));
        delayRow.addView(labeled("Start ms", delayField), weight(1));
        delayRow.addView(labeled("Char ms", charDelayField), weight(1));
        delayRow.addView(labeled("Line ms", lineDelayField), weight(1));
        adv.addView(delayRow);

        deadKeys = check("PC uses US-International layout (dead keys ' \" ` ~ ^)", prefs.getBoolean("deadKeys", false));
        adv.addView(deadKeys);
        controls.addView(adv);
        root.addView(controls);

        // Log on a second LCD
        root.addView(label("Log"));
        logView = text("", LCD_INK, 11);
        logView.setTextIsSelectable(true);
        logView.setMinLines(4);
        GradientDrawable logBg = box(ORANGE, 0xFF2A2A2A, 6);
        logBg.setStroke(dp(4), 0xFF2A2A2A);
        logView.setBackground(logBg);
        logView.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(logView);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.addView(root);
        setContentView(scroll);
    }

    private EditText numberField(int value) {
        EditText e = field("");
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(value));
        e.setGravity(Gravity.CENTER);
        return e;
    }

    private LinearLayout labeled(String caption, View v) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(caption, TEXT_DIM, 11);
        t.setPadding(dp(2), 0, 0, dp(2));
        l.addView(t);
        l.addView(v);
        return l;
    }

    /** Spinner adapter in Flipper colours. */
    private ArrayAdapter<String> deviceAdapter(List<String> names) {
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return style(super.getView(position, convertView, parent));
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return style(super.getDropDownView(position, convertView, parent));
            }

            private View style(View v) {
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(TEXT);
                    t.setTypeface(Typeface.MONOSPACE);
                    t.setTextSize(13);
                }
                return v;
            }
        };
    }

    private void saveSettings() {
        prefs.edit()
                .putBoolean("enterAfter", enterAfter.isChecked())
                .putBoolean("raw", rawMode.isChecked())
                .putString("appName", appNameField.getText().toString().trim())
                .putInt("delay", parseInt(delayField.getText().toString(), 500))
                .putInt("charDelay", parseInt(charDelayField.getText().toString(), 50))
                .putInt("lineDelay", parseInt(lineDelayField.getText().toString(), 30))
                .putBoolean("deadKeys", deadKeys.isChecked())
                .apply();
    }

    private Ducky.Config scriptConfig() {
        Ducky.Config c = new Ducky.Config();
        c.startDelayMs = Math.max(0, parseInt(delayField.getText().toString(), 500));
        c.charDelayMs = Math.max(0, Math.min(1000, parseInt(charDelayField.getText().toString(), 50)));
        c.lineDelayMs = Math.max(0, Math.min(5000, parseInt(lineDelayField.getText().toString(), 30)));
        c.deadKeys = deadKeys.isChecked();
        return c;
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private void setStatus(String s) {
        runOnUiThread(new Runnable() { public void run() { status.setText(s); } });
    }

    /** Single place that syncs the UI with the link state; safe to call from any thread. */
    private void refreshConnectionUi() {
        runOnUiThread(new Runnable() { public void run() {
            boolean on = link.isReady();
            connectBtn.setEnabled(true);
            connectBtn.setText(on ? "Disconnect" : "Connect");
            deviceSpinner.setEnabled(!on);
            if (on) {
                controls.setVisibility(View.VISIBLE);
            } else {
                View f = getCurrentFocus();
                if (f != null) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
                    f.clearFocus();
                }
                controls.setVisibility(View.GONE);
                status.setText("Not connected");
            }
        }});
    }

    @Override
    public void onLog(String msg) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + msg + "\n";
        runOnUiThread(new Runnable() { public void run() {
            CharSequence old = logView.getText();
            String all = line + old;
            if (all.length() > 6000) all = all.substring(0, 6000);
            logView.setText(all);
        }});
    }

    @Override
    public void onDisconnected() {
        onLog("Disconnected");
        setStatus("Not connected");
        refreshConnectionUi();
    }

    // ---------------------------------------------------------------- text file upload

    private static final int REQ_PICK_TXT = 42;
    private static final int MAX_TXT_BYTES = 256 * 1024;

    private void pickTextFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        try {
            startActivityForResult(i, REQ_PICK_TXT);
        } catch (Exception e) {
            onLog("No file picker available on this phone");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_TXT || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(new Runnable() { public void run() {
            try {
                final String text = readVerifiedTxt(uri);
                runOnUiThread(new Runnable() { public void run() {
                    input.setText(text);
                    input.setSelection(text.length());
                    if (rawMode.isChecked()) onLog("Note: Raw DuckyScript is on, the file will be sent as a script");
                }});
            } catch (Exception e) {
                onLog("File rejected: " + e.getMessage());
            }
        }}).start();
    }

    /** Loads a file only if it really is a plain text (.txt) file; throws with a reason otherwise. */
    private String readVerifiedTxt(Uri uri) throws Exception {
        // 1. File name must end in .txt
        String name = null;
        long size = -1;
        Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int si = c.getColumnIndex(OpenableColumns.SIZE);
                    if (ni >= 0) name = c.getString(ni);
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                }
            } finally {
                c.close();
            }
        }
        if (name == null || !name.toLowerCase(Locale.ROOT).endsWith(".txt")) {
            throw new Exception("not a .txt file" + (name != null ? " (" + name + ")" : ""));
        }

        // 2. Reported MIME type must be text/plain (unknown/generic is left to the content check)
        String mime = getContentResolver().getType(uri);
        if (mime != null && !mime.equalsIgnoreCase("text/plain")
                && !mime.equalsIgnoreCase("application/octet-stream")) {
            throw new Exception(name + " has type " + mime + ", not text/plain");
        }

        // 3. Size limit
        if (size > MAX_TXT_BYTES) throw new Exception(name + " is larger than " + (MAX_TXT_BYTES / 1024) + " KB");
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("cannot open " + name);
        try {
            byte[] chunk = new byte[8192];
            int n;
            while ((n = in.read(chunk)) > 0) {
                buf.write(chunk, 0, n);
                if (buf.size() > MAX_TXT_BYTES) throw new Exception(name + " is larger than " + (MAX_TXT_BYTES / 1024) + " KB");
            }
        } finally {
            in.close();
        }
        byte[] bytes = buf.toByteArray();

        // 4. Content must be text: no UTF-16, no NUL bytes, valid UTF-8, no binary control characters
        if (bytes.length >= 2 && ((bytes[0] == (byte) 0xFF && bytes[1] == (byte) 0xFE)
                || (bytes[0] == (byte) 0xFE && bytes[1] == (byte) 0xFF))) {
            throw new Exception(name + " is UTF-16; save it as UTF-8 or ASCII");
        }
        for (byte b : bytes) {
            if (b == 0) throw new Exception(name + " contains binary data");
        }
        String text;
        try {
            CharsetDecoder dec = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT);
            text = dec.decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            throw new Exception(name + " is not valid UTF-8/ASCII text");
        }
        if (text.startsWith("﻿")) text = text.substring(1);
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch < 0x20 && ch != '\n' && ch != '\r' && ch != '\t' && ch != '\f') {
                throw new Exception(name + " contains control characters (0x"
                        + Integer.toHexString(ch) + "), not plain text");
            }
        }
        if (text.trim().isEmpty()) throw new Exception(name + " is empty");
        onLog("Loaded " + name + " (" + bytes.length + " bytes)");
        return text;
    }

    // ---------------------------------------------------------------- devices

    private void loadDevices() {
        devices.clear();
        List<String> names = new ArrayList<>();
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            onLog("No Bluetooth adapter on this phone");
        } else if (!adapter.isEnabled()) {
            onLog("Bluetooth is off on the phone");
        } else {
            try {
                Set<BluetoothDevice> bonded = adapter.getBondedDevices();
                List<BluetoothDevice> flippers = new ArrayList<>();
                List<BluetoothDevice> others = new ArrayList<>();
                for (BluetoothDevice d : bonded) {
                    if (d.getType() == BluetoothDevice.DEVICE_TYPE_CLASSIC) continue;
                    String n = d.getName() == null ? "" : d.getName();
                    if (n.toLowerCase(Locale.ROOT).contains("flipper")) flippers.add(d);
                    else others.add(d);
                }
                devices.addAll(flippers);
                devices.addAll(others);
            } catch (SecurityException e) {
                onLog("Bluetooth permission denied");
            }
        }
        String last = prefs.getString("device", null);
        int sel = 0;
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            names.add((d.getName() == null ? "(no name)" : d.getName()) + "  " + d.getAddress());
            if (d.getAddress().equals(last)) sel = i;
        }
        if (devices.isEmpty()) {
            names.add("No paired BLE devices — pair the Flipper first");
        }
        ArrayAdapter<String> a = deviceAdapter(names);
        deviceSpinner.setAdapter(a);
        deviceSpinner.setSelection(sel);
    }

    private BluetoothDevice selectedDevice() {
        int i = deviceSpinner.getSelectedItemPosition();
        return (i >= 0 && i < devices.size()) ? devices.get(i) : null;
    }

    private void toggleConnect() {
        saveSettings();
        if (link.isConnected()) {
            connectBtn.setEnabled(false);
            worker.execute(new Runnable() { public void run() {
                link.disconnect();
                onLog("Disconnected");
                setStatus("Not connected");
                refreshConnectionUi();
            }});
            return;
        }
        BluetoothDevice d = selectedDevice();
        if (d == null) {
            onLog("Select a paired Flipper first");
            return;
        }
        prefs.edit().putString("device", d.getAddress()).apply();
        connectBtn.setEnabled(false);
        connectBtn.setText("Connecting…");
        worker.execute(new Runnable() { public void run() {
            try {
                setStatus("Connecting…");
                link.connect(d);
                setStatus("Connected to " + d.getName());
            } catch (Exception e) {
                onLog("Error: " + e.getMessage());
                setStatus("Not connected");
            }
            refreshConnectionUi();
        }});
    }

    // ---------------------------------------------------------------- sending

    private void sendText() {
        saveSettings();
        String text = input.getText().toString();
        Ducky.Config cfg = scriptConfig();
        if (rawMode.isChecked()) {
            if (text.trim().isEmpty()) return;
            queueScript(Ducky.raw(text, cfg), "script");
        } else {
            if (text.isEmpty() && !enterAfter.isChecked()) return;
            Ducky.Result r = Ducky.fromText(text, enterAfter.isChecked(), cfg);
            if (r.dropped > 0) onLog("Note: " + r.dropped + " character(s) Bad USB cannot type were skipped");
            queueScript(r.script, text.length() + " chars");
        }
    }

    private void sendKey(String combo) {
        saveSettings();
        int repeat = Math.max(1, Math.min(200, parseInt(repeatField.getText().toString(), 1)));
        queueScript(Ducky.key(combo, repeat, scriptConfig()), combo + (repeat > 1 ? " ×" + repeat : ""));
    }

    private void queueScript(String script, String what) {
        final byte[] data = script.getBytes(StandardCharsets.US_ASCII);
        final String appPref = appNameField.getText().toString().trim();
        worker.execute(new Runnable() { public void run() {
            try {
                if (!link.isReady()) throw new Exception("Not connected");
                onLog("Sending " + what + "…");
                closeRunningApp();
                link.mkdir(SCRIPT_DIR);
                fileToggle ^= 1;
                String path = SCRIPT_DIR + "/_remote_kbd_" + fileToggle + ".txt";
                link.writeFile(path, data);
                startBadUsb(appPref, path);
                Thread.sleep(700);
                link.pressButton(FlipperLink.KEY_OK);
                onLog("Typing on the computer");
            } catch (Exception e) {
                onLog("Error: " + e.getMessage());
            }
        }});
    }

    /** Presses Back until no app is running on the Flipper (e.g. the previous Bad USB session). */
    private void closeRunningApp() throws Exception {
        for (int i = 0; i < 6; i++) {
            if (!link.isAppRunning()) return;
            link.pressButton(FlipperLink.KEY_BACK);
            Thread.sleep(450);
        }
        if (link.isAppRunning()) {
            throw new Exception("An app on the Flipper won't close. Return to the Flipper's home screen and try again.");
        }
    }

    private void startBadUsb(String appPref, String path) throws Exception {
        List<String> candidates = new ArrayList<>();
        if (!appPref.isEmpty()) candidates.add(appPref);
        if (workingAppName != null && !candidates.contains(workingAppName)) candidates.add(workingAppName);
        for (String n : DEFAULT_APP_NAMES) if (!candidates.contains(n)) candidates.add(n);

        for (String name : candidates) {
            int st = link.startApp(name, path);
            if (st == FlipperLink.ST_APP_SYSTEM_LOCKED) {
                closeRunningApp();
                st = link.startApp(name, path);
            }
            if (st == FlipperLink.ST_OK) {
                if (!name.equals(workingAppName)) onLog("Bad USB started as \"" + name + "\"");
                workingAppName = name;
                return;
            }
            if (st != FlipperLink.ST_APP_CANT_START) {
                throw new Exception("Starting Bad USB failed: " + FlipperLink.statusName(st)
                        + (st == FlipperLink.ST_APP_SYSTEM_LOCKED ? " (is the Flipper PIN-locked?)" : ""));
            }
        }
        throw new Exception("Bad USB app not found. Enter its name under Advanced (e.g. the name shown in the Flipper menu).");
    }
}
