package nl.zarco.flipkbd;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * BLE link to a bonded Flipper Zero using its serial service, speaking the Flipper RPC
 * protocol (varint-length-prefixed protobuf PB.Main messages).
 * All public methods are blocking and must be called from a background thread.
 */
final class FlipperLink {

    interface Listener {
        void onLog(String msg);
        void onDisconnected();
    }

    // Flipper serial service and characteristics
    static final UUID SERVICE = UUID.fromString("8fe5b3d5-2e7f-4a98-2a48-7acc60fe0000");
    static final UUID CHAR_61 = UUID.fromString("19ed82ae-ed21-4c9d-4145-228e61fe0000");
    static final UUID CHAR_62 = UUID.fromString("19ed82ae-ed21-4c9d-4145-228e62fe0000");
    static final UUID CHAR_FLOW = UUID.fromString("19ed82ae-ed21-4c9d-4145-228e63fe0000");
    static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    // PB.Main oneof field numbers (flipperzero-protobuf, flipper.proto)
    static final int F_PING_REQ = 5;
    static final int F_PING_RESP = 6;
    static final int F_STORAGE_WRITE = 11;
    static final int F_STORAGE_MKDIR = 13;
    static final int F_APP_START = 16;
    static final int F_APP_LOCK_REQ = 17;
    static final int F_APP_LOCK_RESP = 18;
    static final int F_GUI_INPUT = 23;

    // gui.InputKey / gui.InputType
    static final int KEY_UP = 0, KEY_DOWN = 1, KEY_RIGHT = 2, KEY_LEFT = 3, KEY_OK = 4, KEY_BACK = 5;
    static final int TYPE_PRESS = 0, TYPE_RELEASE = 1, TYPE_SHORT = 2;

    // Selected PB.CommandStatus values
    static final int ST_OK = 0;
    static final int ST_STORAGE_EXIST = 6;
    static final int ST_APP_CANT_START = 16;
    static final int ST_APP_SYSTEM_LOCKED = 17;

    private static final long OP_TIMEOUT_MS = 10000;

    private final Context ctx;
    private final Listener listener;

    private volatile BluetoothGatt gatt;
    private volatile boolean connected;
    private BluetoothGattCharacteristic writeChar;
    private BluetoothGattCharacteristic readChar;
    private BluetoothGattCharacteristic flowChar;
    private volatile int mtu = 23;
    private volatile int flowFree = 512;
    private final Object flowLock = new Object();

    // Single outstanding GATT operation
    private volatile CountDownLatch opLatch;
    private volatile int opStatus;
    private volatile byte[] opValue;
    private CountDownLatch connectLatch;

    private final ByteArrayOutputStream rxBuf = new ByteArrayOutputStream();
    private final Map<Integer, Pending> pending = new ConcurrentHashMap<>();
    private int nextCommandId = 1;

    static final class Response {
        int status = -1;
        final List<Pb.Field> contents = new ArrayList<>();

        Pb.Field content(int field) {
            for (Pb.Field f : contents) if (f.number == field) return f;
            return null;
        }
    }

    private static final class Pending {
        final CountDownLatch done = new CountDownLatch(1);
        final Response response = new Response();
    }

    FlipperLink(Context ctx, Listener listener) {
        this.ctx = ctx.getApplicationContext();
        this.listener = listener;
    }

    private volatile boolean ready;

    boolean isConnected() {
        return connected;
    }

    /** True only when the link is connected and the RPC session has answered a ping. */
    boolean isReady() {
        return ready && connected;
    }

    private void log(String s) {
        listener.onLog(s);
    }

    // ---------------------------------------------------------------- connection

    void connect(BluetoothDevice device) throws Exception {
        try {
            connectInternal(device);
            ready = true;
        } catch (Exception e) {
            disconnect();
            throw e;
        }
    }

    private void connectInternal(BluetoothDevice device) throws Exception {
        disconnect();
        connectLatch = new CountDownLatch(1);
        log("Connecting to " + device.getName() + " (" + device.getAddress() + ")…");
        gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE);
        if (gatt == null) throw new Exception("connectGatt failed");
        if (!connectLatch.await(20, TimeUnit.SECONDS) || !connected) {
            disconnect();
            throw new Exception("Connection timed out. Is the Flipper on, in range and Bluetooth enabled on it?");
        }

        beginOp();
        if (gatt.requestMtu(512)) {
            awaitOp("MTU");
        } else {
            opLatch = null;
        }
        log("MTU " + mtu);

        beginOp();
        if (!gatt.discoverServices()) throw new Exception("discoverServices failed");
        awaitOp("Service discovery");

        BluetoothGattService svc = gatt.getService(SERVICE);
        if (svc == null) {
            disconnect();
            throw new Exception("Flipper serial service not found. Close any Bluetooth Remote / BLE HID app on the Flipper and try again.");
        }
        // Firmware naming of RX/TX differs between sources, so pick by properties.
        for (UUID u : new UUID[]{CHAR_61, CHAR_62}) {
            BluetoothGattCharacteristic c = svc.getCharacteristic(u);
            if (c == null) continue;
            int p = c.getProperties();
            if ((p & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) {
                writeChar = c;
            } else if ((p & (BluetoothGattCharacteristic.PROPERTY_INDICATE | BluetoothGattCharacteristic.PROPERTY_NOTIFY)) != 0) {
                readChar = c;
            }
        }
        flowChar = svc.getCharacteristic(CHAR_FLOW);
        if (writeChar == null || readChar == null) {
            disconnect();
            throw new Exception("Unexpected serial service layout");
        }

        subscribe(readChar);
        if (flowChar != null) {
            subscribe(flowChar);
            beginOp();
            if (gatt.readCharacteristic(flowChar)) {
                awaitOp("Read flow control");
                if (opValue != null && opValue.length >= 4) updateFlow(opValue);
            } else {
                opLatch = null;
            }
        }

        // Verify that the RPC session answers.
        Response r = request(F_PING_REQ, new Pb().bytes(1, new byte[]{1, 2, 3, 4}).build(), 5000);
        if (r.status != ST_OK) throw new Exception("Ping failed: " + statusName(r.status));
        log("Connected, RPC session OK");
    }

    void disconnect() {
        BluetoothGatt g = gatt;
        gatt = null;
        ready = false;
        connected = false;
        if (g != null) {
            try {
                g.disconnect();
                g.close();
            } catch (Exception ignored) {
            }
        }
        failAllPending();
        synchronized (rxBuf) {
            rxBuf.reset();
        }
    }

    private void subscribe(BluetoothGattCharacteristic c) throws Exception {
        gatt.setCharacteristicNotification(c, true);
        BluetoothGattDescriptor d = c.getDescriptor(CCCD);
        if (d == null) return;
        boolean indicate = (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
        d.setValue(indicate ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        beginOp();
        if (!gatt.writeDescriptor(d)) throw new Exception("writeDescriptor failed");
        awaitOp("Subscribe");
        if (opStatus != BluetoothGatt.GATT_SUCCESS) {
            throw new Exception("Subscribe failed (status " + opStatus + "). Is the Flipper paired with this phone?");
        }
    }

    private void beginOp() {
        opStatus = -1;
        opValue = null;
        opLatch = new CountDownLatch(1);
    }

    private void awaitOp(String what) throws Exception {
        CountDownLatch l = opLatch;
        if (l != null && !l.await(OP_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
            throw new Exception(what + " timed out");
        }
        if (!connected) throw new Exception("Disconnected during " + what);
    }

    private void finishOp(int status, byte[] value) {
        opStatus = status;
        opValue = value;
        CountDownLatch l = opLatch;
        if (l != null) l.countDown();
    }

    private void updateFlow(byte[] v) {
        int free = ((v[0] & 0xFF) << 24) | ((v[1] & 0xFF) << 16) | ((v[2] & 0xFF) << 8) | (v[3] & 0xFF);
        synchronized (flowLock) {
            flowFree = free;
            flowLock.notifyAll();
        }
    }

    // ---------------------------------------------------------------- raw I/O

    private synchronized void writeRaw(byte[] data) throws Exception {
        int off = 0;
        while (off < data.length) {
            if (!connected) throw new Exception("Not connected");
            int chunk;
            synchronized (flowLock) {
                long deadline = System.currentTimeMillis() + OP_TIMEOUT_MS;
                while (flowChar != null && flowFree <= 0) {
                    long wait = deadline - System.currentTimeMillis();
                    if (wait <= 0) throw new Exception("Flipper receive buffer stayed full");
                    flowLock.wait(wait);
                }
                chunk = Math.min(data.length - off, Math.max(20, mtu - 3));
                if (flowChar != null) chunk = Math.min(chunk, flowFree);
                if (flowChar != null) flowFree -= chunk;
            }
            byte[] part = new byte[chunk];
            System.arraycopy(data, off, part, 0, chunk);
            writeChar.setValue(part);
            writeChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            beginOp();
            if (!gatt.writeCharacteristic(writeChar)) throw new Exception("writeCharacteristic failed");
            awaitOp("Write");
            if (opStatus != BluetoothGatt.GATT_SUCCESS) throw new Exception("Write failed (status " + opStatus + ")");
            off += chunk;
        }
    }

    private void onRx(byte[] data) {
        synchronized (rxBuf) {
            rxBuf.write(data, 0, data.length);
            while (true) {
                byte[] buf = rxBuf.toByteArray();
                int[] pos = {0};
                long len;
                try {
                    len = Pb.readVarint(buf, pos);
                } catch (IndexOutOfBoundsException e) {
                    return; // incomplete length prefix
                }
                if (buf.length - pos[0] < len) return; // incomplete message
                byte[] msg = new byte[(int) len];
                System.arraycopy(buf, pos[0], msg, 0, (int) len);
                int consumed = pos[0] + (int) len;
                rxBuf.reset();
                rxBuf.write(buf, consumed, buf.length - consumed);
                try {
                    handleMain(msg);
                } catch (Exception e) {
                    log("Bad RPC message: " + e.getMessage());
                }
            }
        }
    }

    private void handleMain(byte[] msg) {
        int id = 0, status = 0;
        boolean hasNext = false;
        Pb.Field content = null;
        for (Pb.Field f : Pb.decode(msg)) {
            if (f.number == 1) id = (int) f.value;
            else if (f.number == 2) status = (int) f.value;
            else if (f.number == 3) hasNext = f.value != 0;
            else if (f.wireType == 2) content = f;
        }
        Pending p = pending.get(id);
        if (p == null) return; // unsolicited message
        p.response.status = status;
        if (content != null) p.response.contents.add(content);
        if (!hasNext) {
            pending.remove(id);
            p.done.countDown();
        }
    }

    private void failAllPending() {
        for (Pending p : pending.values()) p.done.countDown();
        pending.clear();
    }

    // ---------------------------------------------------------------- RPC

    private static byte[] frame(int id, int field, byte[] content, boolean hasNext) {
        Pb m = new Pb().varint(1, id);
        if (hasNext) m.bool(3, true);
        m.bytes(field, content);
        byte[] body = m.build();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        Pb.writeVarint(o, body.length);
        o.write(body, 0, body.length);
        return o.toByteArray();
    }

    private synchronized int newId() {
        int id = nextCommandId++;
        if (nextCommandId > 0x7FFFFFF0) nextCommandId = 1;
        return id;
    }

    Response request(int field, byte[] content, long timeoutMs) throws Exception {
        return requestParts(field, java.util.Collections.singletonList(content), timeoutMs);
    }

    /** Sends a (possibly multi-part, has_next) request and waits for the final response. */
    Response requestParts(int field, List<byte[]> parts, long timeoutMs) throws Exception {
        if (!connected) throw new Exception("Not connected");
        int id = newId();
        Pending p = new Pending();
        pending.put(id, p);
        try {
            for (int i = 0; i < parts.size(); i++) {
                writeRaw(frame(id, field, parts.get(i), i < parts.size() - 1));
            }
            if (!p.done.await(timeoutMs, TimeUnit.MILLISECONDS)) throw new Exception("No response from Flipper");
            if (!connected) throw new Exception("Disconnected");
            return p.response;
        } finally {
            pending.remove(id);
        }
    }

    // ---------------------------------------------------------------- high-level helpers

    boolean isAppRunning() throws Exception {
        Response r = request(F_APP_LOCK_REQ, new byte[0], 5000);
        if (r.status != ST_OK) throw new Exception("Lock status: " + statusName(r.status));
        Pb.Field c = r.content(F_APP_LOCK_RESP);
        if (c == null) return false;
        for (Pb.Field f : Pb.decode(c.data)) if (f.number == 1) return f.value != 0;
        return false;
    }

    void pressButton(int key) throws Exception {
        for (int type : new int[]{TYPE_PRESS, TYPE_SHORT, TYPE_RELEASE}) {
            Response r = request(F_GUI_INPUT, new Pb().varint(1, key).varint(2, type).build(), 5000);
            if (r.status != ST_OK) throw new Exception("Input event: " + statusName(r.status));
        }
    }

    void mkdir(String path) throws Exception {
        Response r = request(F_STORAGE_MKDIR, new Pb().string(1, path).build(), 5000);
        if (r.status != ST_OK && r.status != ST_STORAGE_EXIST) throw new Exception("mkdir: " + statusName(r.status));
    }

    void writeFile(String path, byte[] data) throws Exception {
        final int chunk = 350;
        List<byte[]> parts = new ArrayList<>();
        int off = 0;
        do {
            int n = Math.min(chunk, data.length - off);
            byte[] piece = new byte[n];
            System.arraycopy(data, off, piece, 0, n);
            byte[] file = new Pb().bytes(4, piece).build();
            parts.add(new Pb().string(1, path).bytes(2, file).build());
            off += n;
        } while (off < data.length);
        Response r = requestParts(F_STORAGE_WRITE, parts, 15000);
        if (r.status != ST_OK) throw new Exception("Write " + path + ": " + statusName(r.status));
    }

    int startApp(String name, String args) throws Exception {
        Pb p = new Pb().string(1, name);
        if (args != null) p.string(2, args);
        return request(F_APP_START, p.build(), 8000).status;
    }

    static String statusName(int s) {
        switch (s) {
            case 0: return "OK";
            case 1: return "ERROR";
            case 2: return "ERROR_DECODE";
            case 3: return "ERROR_NOT_IMPLEMENTED";
            case 4: return "ERROR_BUSY";
            case 5: return "STORAGE_NOT_READY (SD card?)";
            case 6: return "STORAGE_EXIST";
            case 7: return "STORAGE_NOT_EXIST";
            case 8: return "STORAGE_INVALID_PARAMETER";
            case 9: return "STORAGE_DENIED";
            case 10: return "STORAGE_INVALID_NAME";
            case 11: return "STORAGE_INTERNAL";
            case 13: return "STORAGE_ALREADY_OPEN";
            case 16: return "APP_CANT_START";
            case 17: return "APP_SYSTEM_LOCKED";
            default: return "status " + s;
        }
    }

    // ---------------------------------------------------------------- GATT callback

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                connected = true;
                if (connectLatch != null) connectLatch.countDown();
            } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                boolean was = connected;
                ready = false;
                connected = false;
                if (connectLatch != null) connectLatch.countDown();
                finishOp(-1, null);
                failAllPending();
                try {
                    g.close();
                } catch (Exception ignored) {
                }
                if (gatt == g) gatt = null;
                if (was) listener.onDisconnected();
            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt g, int newMtu, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = newMtu;
            finishOp(status, null);
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            finishOp(status, null);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            finishOp(status, null);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            finishOp(status, c.getValue());
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            finishOp(status, null);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] v = c.getValue();
            if (v == null) return;
            if (CHAR_FLOW.equals(c.getUuid())) {
                if (v.length >= 4) updateFlow(v);
            } else {
                onRx(v);
            }
        }
    };
}
