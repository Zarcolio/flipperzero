package nl.zarco.flipkbd;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Minimal protobuf encoder/decoder, enough for the Flipper Zero RPC messages used here. */
final class Pb {
    private final ByteArrayOutputStream out = new ByteArrayOutputStream();

    static void writeVarint(ByteArrayOutputStream o, long v) {
        while ((v & ~0x7FL) != 0) {
            o.write((int) ((v & 0x7F) | 0x80));
            v >>>= 7;
        }
        o.write((int) v);
    }

    Pb varint(int field, long value) {
        writeVarint(out, ((long) field << 3));
        writeVarint(out, value);
        return this;
    }

    Pb bool(int field, boolean value) {
        return varint(field, value ? 1 : 0);
    }

    Pb bytes(int field, byte[] value) {
        writeVarint(out, ((long) field << 3) | 2);
        writeVarint(out, value.length);
        out.write(value, 0, value.length);
        return this;
    }

    Pb string(int field, String value) {
        return bytes(field, value.getBytes(StandardCharsets.UTF_8));
    }

    byte[] build() {
        return out.toByteArray();
    }

    /** One decoded field. For length-delimited fields 'data' is set, otherwise 'value'. */
    static final class Field {
        final int number;
        final int wireType;
        final long value;
        final byte[] data;

        Field(int number, int wireType, long value, byte[] data) {
            this.number = number;
            this.wireType = wireType;
            this.value = value;
            this.data = data;
        }
    }

    static List<Field> decode(byte[] buf) {
        List<Field> fields = new ArrayList<>();
        int[] pos = {0};
        while (pos[0] < buf.length) {
            long tag = readVarint(buf, pos);
            int number = (int) (tag >>> 3);
            int wire = (int) (tag & 7);
            switch (wire) {
                case 0:
                    fields.add(new Field(number, wire, readVarint(buf, pos), null));
                    break;
                case 1:
                    pos[0] += 8;
                    break;
                case 2: {
                    int len = (int) readVarint(buf, pos);
                    byte[] d = new byte[len];
                    System.arraycopy(buf, pos[0], d, 0, len);
                    pos[0] += len;
                    fields.add(new Field(number, wire, 0, d));
                    break;
                }
                case 5:
                    pos[0] += 4;
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported wire type " + wire);
            }
        }
        return fields;
    }

    static long readVarint(byte[] buf, int[] pos) {
        long result = 0;
        int shift = 0;
        while (true) {
            if (pos[0] >= buf.length) throw new IndexOutOfBoundsException("Truncated varint");
            int b = buf[pos[0]++] & 0xFF;
            result |= (long) (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return result;
            shift += 7;
        }
    }
}
