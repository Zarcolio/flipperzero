package nl.zarco.flipkbd;

/** Builds Flipper Bad USB (DuckyScript) scripts. */
final class Ducky {
    private static final int MAX_STRING_CHUNK = 100;
    /** Dead keys on the Windows "US-International" layout. */
    private static final String DEAD_KEYS = "'\"`~^";

    static final class Config {
        int startDelayMs = 500;
        /** Pause between typed characters (DEFAULT_STRING_DELAY). */
        int charDelayMs = 50;
        /** Pause after every script line, e.g. after each ENTER (DEFAULT_DELAY). */
        int lineDelayMs = 30;
        /** Send SPACE after ' " ` ~ ^ so US-International dead keys produce the plain character. */
        boolean deadKeys = false;
    }

    static final class Result {
        final String script;
        final int dropped;

        Result(String script, int dropped) {
            this.script = script;
            this.dropped = dropped;
        }
    }

    private static String header(Config c) {
        StringBuilder sb = new StringBuilder();
        if (c.startDelayMs > 0) sb.append("DELAY ").append(c.startDelayMs).append('\n');
        if (c.lineDelayMs > 0) sb.append("DEFAULT_DELAY ").append(c.lineDelayMs).append('\n');
        if (c.charDelayMs > 0) sb.append("DEFAULT_STRING_DELAY ").append(c.charDelayMs).append('\n');
        return sb.toString();
    }

    private static void appendString(StringBuilder sb, String s) {
        for (int off = 0; off < s.length(); off += MAX_STRING_CHUNK) {
            sb.append("STRING ").append(s, off, Math.min(s.length(), off + MAX_STRING_CHUNK)).append('\n');
        }
    }

    /** Plain text -> STRING/ENTER lines. Characters Bad USB cannot type are dropped and counted. */
    static Result fromText(String text, boolean enterAtEnd, Config c) {
        StringBuilder sb = new StringBuilder(header(c));
        int dropped = 0;
        String normalized = text.replace("\r\n", "\n").replace('\r', '\n')
                .replace('‘', '\'').replace('’', '\'')
                .replace('“', '"').replace('”', '"')
                .replace('–', '-').replace('—', '-')
                .replace(' ', ' ').replace("…", "...")
                .replace('\t', ' ');
        String[] lines = normalized.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            StringBuilder part = new StringBuilder();
            for (char ch : lines[i].toCharArray()) {
                if (ch < 0x20 || ch > 0x7E) {
                    dropped++;
                    continue;
                }
                part.append(ch);
                if (c.deadKeys && DEAD_KEYS.indexOf(ch) >= 0) {
                    appendString(sb, part.toString());
                    sb.append("SPACE\n");
                    part.setLength(0);
                }
            }
            appendString(sb, part.toString());
            if (i < lines.length - 1) sb.append("ENTER\n");
        }
        if (enterAtEnd) sb.append("ENTER\n");
        return new Result(sb.toString(), dropped);
    }

    /** A single key or key combination, optionally repeated. */
    static String key(String combo, int repeat, Config c) {
        StringBuilder sb = new StringBuilder(header(c));
        sb.append(combo).append('\n');
        if (repeat > 1) sb.append("REPEAT ").append(repeat - 1).append('\n');
        return sb.toString();
    }

    static String raw(String script, Config c) {
        String s = script.replace("\r\n", "\n");
        if (!s.endsWith("\n")) s += "\n";
        return header(c) + s;
    }
}
